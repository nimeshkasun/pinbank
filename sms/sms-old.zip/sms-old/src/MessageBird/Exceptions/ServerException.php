<?php

namespace MessageBird\Exceptions;

/**
 * Class ServerException
 *
 * @package MessageBird\Exceptions
 */
class ServerException extends MessageBirdException
{

}
