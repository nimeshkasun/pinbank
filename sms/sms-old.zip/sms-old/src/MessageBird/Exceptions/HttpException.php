<?php

namespace MessageBird\Exceptions;

/**
 * Class HttpException
 *
 * @package MessageBird\Exceptions
 */
class HttpException extends MessageBirdException
{

}
